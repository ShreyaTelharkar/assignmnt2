import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ProductListComponent }  from './product-listcomponent';
import { FormsModule } from '@angular/forms';


@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ ProductListComponent ],
  bootstrap:    [ ProductListComponent ]
})
export class AppModule { }
